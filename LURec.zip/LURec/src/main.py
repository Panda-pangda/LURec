# -*- coding: utf-8 -*-

import os
import torch
import shutil
import argparse
import numpy as np

def show_args_info(args):
    print(f"--------------------Configure Info:--------------------")
    with open(args.log_file, 'a') as f:
        for arg in vars(args):
            info = f"{arg:<30} : {getattr(args, arg):>35}"
            print(info)
            f.write(info + '\n')


def main():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()

    set_seed(args.seed)
    check_path(args.output_dir)

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_id
    args.cuda_condition = torch.cuda.is_available() and not args.no_cuda
    print("Using Cuda:", torch.cuda.is_available())

    args.data_file = os.path.join(args.data_dir, args.data_name, args.data_name + '_item.txt')
    args.time_file = os.path.join(args.data_dir, args.data_name, args.data_name + '_time.txt')

    user_seq, time_seq, max_item, valid_rating_matrix, test_rating_matrix, not_aug_users = get_user_seqs(args)
    args.item_size = max_item + 2
    args.mask_id = max_item + 1

    # save model and args
    args_str = f'{args.model_name}-{args.data_name}-{args.model_idx}'
    args.checkpoint_path = os.path.join(args.output_dir, args_str)
    if os.path.exists(args.checkpoint_path):
        shutil.rmtree(args.checkpoint_path, ignore_errors=True)
    os.mkdir(args.checkpoint_path)
    args.log_file = os.path.join(args.checkpoint_path, args_str + '.txt')
    args.test_log_file = os.path.join(args.checkpoint_path, args_str + '-test.txt')

    show_args_info(args)

    # set item score in train set to `0` in validation
    args.train_matrix = valid_rating_matrix

    # -----------   pre-computation for item similarity   ------------ #
    args.similarity_model_path = os.path.join(args.data_dir,
                                              args.data_name + '_' + args.similarity_model_name + '_similarity.pkl')

    offline_similarity_model = OfflineItemSimilarity(data_file=args.data_file,
                                                     similarity_path=args.similarity_model_path,
                                                     model_name=args.similarity_model_name, dataset_name=args.data_name)
    args.offline_similarity_model = offline_similarity_model

    # -----------   online based on shared item embedding for item similarity --------- #
    online_similarity_model = OnlineItemSimilarity(args.item_size)
    args.online_similarity_model = online_similarity_model

    # training data for node classification
    train_dataset = RecWithContrastiveLearningDataset(args, user_seq[:int(len(user_seq) * args.training_data_ratio)],
                                                      time_seq, not_aug_users=not_aug_users, data_type='train')
    train_sampler = RandomSampler(train_dataset)
    train_dataloader = DataLoader(train_dataset, sampler=train_sampler, batch_size=args.batch_size)

    eval_dataset = RecWithContrastiveLearningDataset(args, user_seq, time_seq, data_type='valid')
    eval_sampler = SequentialSampler(eval_dataset)
    eval_dataloader = DataLoader(eval_dataset, sampler=eval_sampler, batch_size=args.batch_size)

    test_dataset = RecWithContrastiveLearningDataset(args, user_seq, time_seq, data_type='test')
    test_sampler = SequentialSampler(test_dataset)
    test_dataloader = DataLoader(test_dataset, sampler=test_sampler, batch_size=args.batch_size)

    model = SASRec(args=args)

    trainer = CoSeRecTrainer(model, train_dataloader, eval_dataloader,
                             test_dataloader, args)

    if args.do_eval:
        trainer.args.train_matrix = test_rating_matrix
        trainer.load(args.eval_path)
        print(f'Load model from {args.eval_path} for test!')
        scores, result_info = trainer.test(0, full_sort=True)

    else:
        print(f'Train LURec')
        early_stopping = EarlyStopping(args.checkpoint_path, patience=args.patience, verbose=True)
        for epoch in range(args.epochs):
            trainer.train(epoch)
            # evaluate on NDCG@20
            scores, _ = trainer.valid(epoch, full_sort=True)
            early_stopping(np.array(scores[-1:]), trainer.model)
            if early_stopping.early_stop:
                print("Early stopping")
                break
            if (epoch + 1) % args.test_frequency == 0:
                print('---------------Change to test_rating_matrix!-------------------')
                trainer.args.train_matrix = test_rating_matrix
                scores, result_info = trainer.test(epoch, full_sort=True)
                save_path = os.path.join(args.checkpoint_path, 'epoch-' + str(epoch) + '.pt')
                torch.save(trainer.model.state_dict(), save_path)
                args.train_matrix = valid_rating_matrix

    print('Finish training')


main()
