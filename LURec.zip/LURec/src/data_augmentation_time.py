# -*- coding: utf-8 -*-

import copy
import random
import itertools
import numpy as np


def get_var(tlist):
    length = len(tlist)
    total = 0
    diffs = []

    if length == 1:
        return 0

    for i in range(length - 1):
        diff = abs(tlist[i + 1] - tlist[i])
        diffs.append(diff)
        total = total + diff
    if len(diffs)!= 0:
        avg_diff = total / len(diffs)
    else:
        avg_diff = 0

    total = 0
    for diff in diffs:
        total = total + (diff - avg_diff) ** 2
    if len(diffs) != 0:
        result = total / len(diffs)
    else:
        result=0

    return result

class Replace(object):
    def __init__(self, max_length,  insert_rate=0.4):
        self.max_length = max_length
        self.insert_rate = insert_rate

    def __call__(self, item_sequence, time_sequence):
        copied_item = copy.deepcopy(item_sequence)
        copied_time = copy.deepcopy(time_sequence)
        uniform_segment = self.get_uniform_segment(copied_item, copied_time)

        new_sequence = []
        current_length = 0

        if len(uniform_segment)==0:
            uniform_segment=copied_item
        max_num = int(self.max_length / len(uniform_segment))
        pad_num = random.randint(0, max_num)

        # 只要当前长度小于最大长度，就一直插入均匀段
        for i in range(pad_num):
            new_sequence.extend(uniform_segment + [0])
            current_length += len(uniform_segment) + 1
        # 如果还有空间，就添加原始序列
        if current_length + len(copied_item) <= self.max_length:
            new_sequence.extend(copied_item)
            current_length += len(copied_item)

        # 如果还有空间，就填充0
        if current_length < self.max_length:
            new_sequence.extend([0] * (self.max_length - current_length))
        return new_sequence

    def get_uniform_segment(self, item_sequence, time_sequence):
        diffs = [time_sequence[i + 1] - time_sequence[i] for i in range(len(time_sequence) - 1)]
        min_length = int(len(item_sequence) * self.insert_rate)
        min_var = np.var(diffs, ddof=0)
        f_start = 0
        f_end = len(time_sequence)
        for start in range(0, len(time_sequence)):
            for end in range(start + min_length + 1, len(time_sequence)):
                var = np.var(diffs[start:end + 1], ddof=0)
                if var <= min_var:
                    f_start = start
                    f_end = end
        return item_sequence[f_start + 1:f_end + 1]

class Insert(object):
    def __init__(self, item_similarity_model, mode, insert_rate=0.4, max_insert_num_per_pos=1):
        if type(item_similarity_model) is list:
            self.item_sim_model_1 = item_similarity_model[0]
            self.item_sim_model_2 = item_similarity_model[1]
            self.ensemble = True
        else:
            self.item_similarity_model = item_similarity_model
            self.ensemble = False
        self.mode = mode
        self.insert_rate = insert_rate
        self.max_insert_num_per_pos = max_insert_num_per_pos

    def __call__(self, item_sequence, time_sequence):
        copied_sequence = copy.deepcopy(item_sequence)
        insert_nums = max(int(self.insert_rate * len(copied_sequence)), 1)

        time_diffs = []
        length = len(time_sequence)
        for i in range(length - 1):
            diff = abs(time_sequence[i + 1] - time_sequence[i])
            time_diffs.append(diff)
        assert self.mode in ['maximum', 'minimum']
        diff_sorted = np.argsort(time_diffs)[::-1]
        diff_sorted = diff_sorted.tolist()

        insert_idx = []
        for i in range(insert_nums):
            temp = diff_sorted[i]
            insert_idx.append(temp)
        inserted_sequence = []
        for index, item in enumerate(copied_sequence):

            inserted_sequence += [item]

            if index in insert_idx:
                top_k = random.randint(1, max(1, int(self.max_insert_num_per_pos / insert_nums)))
                if self.ensemble:
                    top_k_one = self.item_sim_model_1.most_similar(item, top_k=top_k, with_score=True)
                    top_k_two = self.item_sim_model_2.most_similar(item, top_k=top_k, with_score=True)
                    inserted_sequence += _ensmeble_sim_models(top_k_one, top_k_two)
                else:
                    inserted_sequence += self.item_similarity_model.most_similar(item, top_k=top_k)
        return inserted_sequence



